package internship;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lauch {
	public static void main(String[] args) throws InterruptedException {
		 // Set path to chromedriver.exe
		System.setProperty("WebDriver.chromedriver", "C:\\Users\\vvodd\\Downloads\\chromedriver-win64 (2).zip\\chromedriver-win64");
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		// Wait for 5 seconds to view the browser
		Thread.sleep(5000);
		System.out.println("launced sucessfully");
		driver.close();
	}
}
