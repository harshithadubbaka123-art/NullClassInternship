package internship;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MultipleProducts {

    private static final WebElement[] products = null;
	WebDriver driver;
    WebDriverWait wait;
    int totalPrice = 0;

    @BeforeClass
    public void setup() {
       
    	//Restrict execution time between 3PM to 6PM
		 LocalTime StartTime = LocalTime.of(6, 0);//11 clock
		 LocalTime EndTime = LocalTime.of(7, 0);//12 clock
//get currentTime 
		 LocalTime currentTime = LocalTime.of(6, 0);
        if (currentTime.isBefore(StartTime) || currentTime.isAfter(EndTime)) {
            System.out.println("Current time is outside the allowed execution hours.");
            throw new SkipException("Skipping tests due to time restriction.");
        } else {
            System.out.println("Current time is within allowed range. Executing logic...");
        }

        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        driver.manage().window().maximize();
    }

    @Test(priority = 0)
    public void checkContinueShopping() {
        driver.get("https://www.amazon.in/");
        List<WebElement> button = driver.findElements(By.linkText("Continue shopping"));
        if (!button.isEmpty() && button.get(0).isDisplayed()) {
            button.get(0).click();
            System.out.println("Continue shopping button clicked successfully.");
        } else {
            System.out.println("Continue shopping button is not present or not visible.");
        }
    }

    @Test(priority = 1)
    public void verifyUsername() {
        String userName = "TestUser99"; // Example username
        if (userName.length() == 10 && userName.matches("^[a-zA-Z0-9]+$")) {
            System.out.println("Username is valid: " + userName);
        } else {
            throw new SkipException("Invalid username. Must be exactly 10 characters and contain no special characters.");
        }
    }

    
    @Test(priority = 2)
    public void addProductsToCart() {
        driver.get("https://www.amazon.in/");

        try {
            // Wait for search box and perform search
            WebElement searchBox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox")));
            searchBox.clear();
            searchBox.sendKeys("laptop accessories");
            driver.findElement(By.id("nav-search-submit-button")).click();
            System.out.println("Search submitted for laptop accessories.");
        } catch (Exception e) {
            System.out.println("Failed to locate or interact with search box: " + e.getMessage());
            throw new SkipException("Search box not found, skipping test.");
        }

        List<WebElement> products;
        try {
            products = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(
                    By.cssSelector("div.s-main-slot div[data-component-type='s-search-result']")));
        } catch (Exception e) {
            System.out.println("No products found: " + e.getMessage());
            throw new SkipException("No search results available, skipping test.");
        }

        if (products == null || products.isEmpty()) {
            System.out.println("Product list is empty.");
            throw new SkipException("No products to process.");
        }

        int addedCount = 0;

        for (WebElement product : products) {
            if (addedCount >= 3) break;

            try {
                String title = product.findElement(By.cssSelector("h2 span")).getText().trim();
                String priceText = product.findElement(By.cssSelector(".a-price-whole")).getText().replace(",", "");
                int price = Integer.parseInt(priceText);

                if (price > 0) {
                    totalPrice += price;

                    String productLink = product.findElement(By.cssSelector("h2 a")).getAttribute("href");
                    ((ChromeDriver) driver).executeScript("window.open(arguments[0], '_blank');", productLink);

                    ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
                    driver.switchTo().window(tabs.get(tabs.size() - 1));

                    try {
                        WebElement addToCartBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-button")));
                        addToCartBtn.click();
                        System.out.println("Added: " + title + " | ₹" + price);
                        addedCount++;
                    } catch (Exception e) {
                        System.out.println("Add to Cart' not found for: " + title);
                    }

                    driver.close();
                    driver.switchTo().window(tabs.get(0));
                }
            } catch (Exception e) {
                System.out.println(" Skipped product due to error: " + e.getMessage());
            }
        }

        System.out.println("Total price of added products: ₹" + totalPrice);
    }

       
                    
         

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
