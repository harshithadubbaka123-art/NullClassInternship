package internship;
import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ProductFilter {

	private static final Function ExceptedCondition = null;
	WebDriver driver;
	WebDriverWait Wait;
	
	
	@BeforeClass
	public void setup() {
		//check the restrict execution time
		LocalTime StartTime = LocalTime.of(3, 0);//11 clock
		 LocalTime EndTime = LocalTime.of(6, 0);//12 clock
		 
              //check the current time is within range
		 LocalTime currentTime = LocalTime.of(3, 0);
		
		 if (!currentTime.isBefore(StartTime) && !currentTime.isAfter(EndTime)) {
	            System.out.println("Current time is within allowed range. Executing logic...");
	            runMainLogic();
	        } else {
	            System.out.println("Current time is outside the allowed execution hours.");
	        }
		 
		 WebDriverManager.chromedriver().setup();
		 driver =new ChromeDriver();
		 Wait =new WebDriverWait(driver,Duration.ofSeconds(15));
		 driver.manage().window().maximize();
	}
	
    
	
	@Test
	
	public void productFilter() {
		driver.get("https://www.amazon.in/");
		
		
		
		 // Try to find "Login" button
		 driver.get("https://www.amazon.in/");
	        List<WebElement> Button = driver.findElements(By.linkText("Continue shopping"));
	        if (!Button.isEmpty() && Button.get(0).isDisplayed()) {
	            Button.get(0).click();
	            System.out.println("Continue shopping button clicked successfully.");
	        } else {
	            System.out.println("Continue shopping button is not present or not visible.");
	        }
		 
		
		//search the product
		  WebElement searchBox = Wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("twotabsearchtextbox")));
	        searchBox.sendKeys("Electronics");
	        searchBox.submit();
	       driver.switchTo().defaultContent(); 
	        //wait for filters all appears
	      //  Wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.s-main-slot")));
	        
	        
	        // Apply price filter > 2000
	        try {
	            WebElement minBox = Wait.until(ExpectedConditions.elementToBeClickable(By.id("low-price")));
	            WebElement goBtn = driver.findElement(By.xpath("//input[@class='a-button-input' and @type='submit']"));

	            minBox.sendKeys("2001");
	            goBtn.click();
	            Wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.s-main-slot")));
		        
	        } catch (Exception e) {
	            System.out.println("Price filter failed: " + e.getMessage());
	        }
	        
	        // Apply rating filter: 4 Stars & up
	        try {
	            WebElement fourStar = Wait.until(ExpectedConditions.elementToBeClickable(
	                    By.xpath("//span[text()='4 Stars & Up']")));
	            fourStar.click();

	            Wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("div.s-main-slot")));
	        } catch (Exception e) {
	            System.out.println("Rating filter failed: " + e.getMessage());
	        }
	        
	        List<WebElement> productTitles = driver.findElements(By.cssSelector("h2 span")); // or use your own selector

	        System.out.println("🧾 Products starting with letter 'C':");
	        for (WebElement titleElement : productTitles) {
	            String title = titleElement.getText().trim();
	            if (title.startsWith("C") || title.startsWith("c")) {
	                System.out.println("➡️ " + title);
	            }
	        }
	}
			   
			    
			

			
			
			
			
			
			

	
	 @AfterClass
	    public void teardown() {
	        if (driver != null) {
	            driver.quit();
	        }
	    }
	private void runMainLogic() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
